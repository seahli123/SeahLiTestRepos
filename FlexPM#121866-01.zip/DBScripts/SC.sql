if OBJECT_ID('udtTMIArchiveSetting') IS NULL
begin

CREATE TABLE [dbo].[udtTMIArchiveSetting](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] int not NULL,
	[Value] int  NULL
) ON [PRIMARY]
end 

GO

if OBJECT_ID('udtTMIArchiveControlBoard') IS NULL
begin

CREATE TABLE [dbo].[udtTMIArchiveControlBoard](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ServiceName] varchar(200) not null,
	[MinBoardID] int not NULL,
	[MaxBoardID] int not NULL,
	[Status]  varchar(200) not null,
	[CreationTime] datetime not null,
	[UpdateTime] datetime null
) ON [PRIMARY]
end 

GO

if OBJECT_ID('udtTMIArchiveException') IS NULL
begin

CREATE TABLE [dbo].[udtTMIArchiveException](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[BoardID] int not NULL,
	[FileName]  varchar(200) not null,
	[ErrorMessage] varchar(max) not null,
	[CreationTime] datetime not null,
	[UpdateTime] datetime null
) ON [PRIMARY]
end 

GO

if OBJECT_ID('udttmiArchiveHeader') IS NULL
begin

CREATE TABLE [dbo].[udttmiArchiveHeader](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[BoardID] int not NULL,
	[FileName]  varchar(200) not null,
	[ServiceName] varchar(200) not null,
	[CreationTime] datetime not null
) ON [PRIMARY]
end 

GO


