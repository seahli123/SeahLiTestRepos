

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udpTMIArchiveProcessData]') AND type in (N'P', N'PC'))
   DROP PROCEDURE [dbo].[udpTMIArchiveProcessData]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[udpTMIArchiveCompleteData]') AND type in (N'P', N'PC'))
   DROP PROCEDURE [dbo].[udpTMIArchiveCompleteData]
GO


/*  
***************************************************************************************************************************************************************************************  
Author: Seah Li
Creation Date: 12th Sept 2020
Explanation: based on board ids to get the panel, position info and populate into xml
FlexPM :121866-01 
Script Version: 
Parameter:  
ModifiedHistory:
***************************************************************************************************************************************************************************************  
*/

create PROCEDURE [dbo].[udpTMIArchiveProcessData]
	-- Add the parameters for the stored procedure here
	@request_xml		NVARCHAR(MAX),
	@signal_xml			NVARCHAR(MAX) OUT,
	@signal_xml_def		NVARCHAR(MAX) OUT,
	@error_code			INT OUT,
	@error_message_xml	NVARCHAR(MAX) OUT,
	@filename			NVARCHAR(200) OUT
	--@extra_data			NVARCHAR(MAX) = NULL
AS
BEGIN

	DECLARE @SPName				VARCHAR(50)
	DECLARE @OperationTime		DATETIME
	DECLARE @ErrorSeverity		INT
	DECLARE @ErrorState			INT
	DECLARE @ErrorLine			INT
	DECLARE @ErrorMsg			NVARCHAR(MAX)
	DECLARE @ErrorCode			BIGINT
	DECLARE @ServiceName		VARCHAR(200) = 'FCSService1'

	SET NOCOUNT ON 
	BEGIN TRY
		DECLARE @CurrDate DATETIME = GETDATE()
		DECLARE @EndDate DATETIME = DATEADD(month, -6, @CurrDate)
		DECLARE @min int, @max int
		DECLARE @xml xml
        DECLARE @BoardID int
		DECLARE @FirstBoardID int
		DECLARE @files as table (ID INT IDENTITY(1,1), filename varchar(max))
		DECLARE @Output as table (ID INT IDENTITY(1,1), XMLStr xml, filename varchar(max))
		DECLARE @SourceRecord int, @RecordPerFile int, @LastProcessID int
		DECLARE @MinBoardID int, @MaxBoardID int, @groupCnt int
		DECLARE @SQL varchar(max)
		DECLARE @fsn varchar(max)

		IF OBJECT_ID('tempdb..#table') IS NOT NULL 
		BEGIN 
			DROP TABLE #table 
		END 		
		CREATE TABLE  #table  (id int IDENTITY(1,1),   boardid int,processed int, groupno int)			

		IF OBJECT_ID('tempdb..#tempXmlTable') IS NOT NULL 
		BEGIN 
			DROP TABLE #tempXmlTable 
		END 		
		CREATE TABLE  #tempXmlTable  ([boardid] BIGINT)									 			  

		DECLARE @GroupTable Table	
		(
			groupNo INT,
			XMLStr XML,
			filename VARCHAR(MAX)
		)  

		SELECT @SourceRecord = Value FROM udtTMIArchiveSetting where Name = 'NumSourceRecords'

		SELECT @RecordPerFile = Value FROM udtTMIArchiveSetting where Name = 'NumRecordPerFile'

		select @MinBoardID = MinBoardID, @MaxBoardID = MaxBoardID from udtTMIArchiveControlBoard 
		where ServiceName = @ServiceName and status = 'Running'

		IF (@MinBoardID is null and @MaxBoardID is null)
		BEGIN
			BEGIN TRAN
				SELECT @LastProcessID = Value 
				FROM udtTMIArchiveSetting with (UPDLOCK,ROWLOCK)
				WHERE Name = 'LastProcessId'

				set @MinBoardID = @LastProcessID + 1
				set @MaxBoardID = @LastProcessID + @SourceRecord 

				Update udtTMIArchiveSetting set Value = @MaxBoardID  WHERE Name = 'LastProcessId'
			COMMIT
		END
		
		insert into #table (boardid,processed )
		select id,0 from board where id > = @MinBoardID and id< = @MaxBoardID

		if exists (select 1 from #table)
		begin
			if exists(select 1 from udtTMIArchiveControlBoard where ServiceName = @ServiceName)
			begin
				update udtTMIArchiveControlBoard set MinBoardID = @MinBoardID, MaxBoardID = @MaxBoardID, [status] = 'Running', UpdateTime = getdate()
				where servicename = @ServiceName
			end
			else
			begin
				insert into udtTMIArchiveControlBoard (ServiceName, MinBoardID, MaxBoardID, Status, CreationTime)
				select @ServiceName,@MinBoardID,@MaxBoardID,'Running', getdate()
			end
		end

		SET @groupCnt = 1
		WHILE (1=1 )
		begin			
			DELETE #tempXmlTable	
			SET @SQL = ''
			SET @SQL = @SQL + ' INSERT INTO #tempXmlTable ([boardid]) '
			SET @SQL = @SQL + ' SELECT TOP '+ CAST( ISNULL(@RecordPerFile, '') AS VARCHAR(MAX))+' boardid FROM  #table WHERE [processed] = 0 '
			EXEC (@SQL)			

			select @fsn = flexflowsn from board where id in (select top 1 boardid from #tempXmlTable)

			SET @xml =
					(SELECT  id, FlexFlowSN,machineid,jobid,projectid,basetype,accuracy,datebegin,datecomplete,datecorrelationbegin,datecorrelationend,filename,creationdate,
						(
								SELECT 
								(
										SELECT		 id, FlexFlowSN ,boardid,CreationDate 
													
													,(select 
													(
													select id,ReferenceDesignator,skid,PackagingUnitId ,PanelId,BoardId,CreationDate  from position c where b.id = c.PanelId  FOR XML PATH('position'), Type 
													) FOR XML PATH('positons'), Type )

										FROM panel b where a.id = b.boardid
										FOR XML PATH('panel'),  TYPE /*, ELEMENTS XSINIL*/
								)FOR XML PATH('panels'), Type
						) FROM board a where id in (select boardid from #tempXmlTable) FOR XML PATH('board'), ROOT ('boards'), TYPE /*,ELEMENTS XSINIL*/
					)

			update #table set processed = 1 where boardid in (select boardid from #tempXmlTable)

			select @filename =@fsn + '_' + CONVERT(varchar,getdate(),112) + cast (DATEDIFF_BIG(MILLISECOND,'1970-01-01', getdate()) as varchar(max))

			INSERT INTO @GroupTable (groupNo, xmlStr, filename)
			VALUES (@groupCnt ,@xml, @filename)

			insert into udttmiArchiveHeader (boardid,filename, ServiceName, CreationTime) 
			select boardid,@filename, @ServiceName, getdate() from #tempXmlTable
			SET @groupCnt =@groupCnt +1
							
			IF (NOT EXISTS (SELECT 1 FROM #table WHERE processed = 0))
			BREAK;
		end

		if exists (select 1 from @GroupTable)
		begin
			select XMLStr, filename from @GroupTable
		end
		else return

		SET @error_code = 0              

	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK
		SET @ErrorSeverity = ERROR_SEVERITY()
		SET @ErrorState = ERROR_STATE()		
		SET	@ErrorLine = ERROR_LINE()
		SET @ErrorMsg = '[' + @SPName + '][Line: '+ CAST(@ErrorLine AS VARCHAR(MAX)) + ']' + ERROR_MESSAGE()	

		SET	@signal_xml = NULL
		SET	@error_code = -1
		SET	@error_message_xml = @ErrorMsg
		--SET	@filename = NULL

		RETURN -1
	END CATCH
	RETURN 0
END


GO

/*  
***************************************************************************************************************************************************************************************  
Author: Seah Li
Creation Date: 12th Sept 2020
Explanation: perform data deletion
FlexPM :121866-01 
Script Version: 
Parameter:  
ModifiedHistory:
***************************************************************************************************************************************************************************************  
*/



 create PROCEDURE [dbo].[udpTMIArchiveCompleteData]
@signal_xml as nvarchar(max),
@signal_xml_def as nvarchar(max),
@error_code as int out,
@error_message_xml as nvarchar(max) out,
@filename as nvarchar(200) out,
@extra_data nvarchar(max) = null

--WITH ENCRYPTION	
AS
begin

	DECLARE @ErrorSeverity		INT
	DECLARE @ErrorState			INT
	DECLARE @ErrorLine			INT
	DECLARE @ErrorMsg			NVARCHAR(MAX)
	DECLARE @ErrorCode			BIGINT
	DECLARE @table as table (ID INT IDENTITY(1,1), BoardID Bigint)
	DECLARE @ServiceName varchar(200) = 'FCSService1'
	DECLARE @BatchSize INT = 10000

begin try

	insert into @table (BoardID)
	select boardid from udttmiArchiveHeader where ServiceName = @ServiceName and filename = @filename 

	if @signal_xml <> ''
	begin
		if @signal_xml = 'Success'
		begin

			while 1 = 1
			begin
			delete top (@BatchSize)
			from QuarantineHistory where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from Quarantine where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from TraceException where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from TraceDataLogging where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from Position where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from Panel where Boardid in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			while 1 = 1
			begin
			delete top (@BatchSize)
			from Board where Id in (SELECT BoardID FROM @table)
			if @@ROWCOUNT < @BatchSize break
			end

			delete udttmiArchiveHeader where boardid in (select boardid from @table)
		end
		else
		begin
			insert into udtTMIArchiveException (boardid,Filename, ErrorMessage,creationtime)
			select boardid, @filename, @signal_xml, getdate() from @table

			delete udttmiArchiveHeader where boardid in (select boardid from @table)
		end
	end

	if not exists (select 1 from udttmiArchiveHeader where servicename = @ServiceName) 
	begin
		update udtTMIArchiveControlBoard set status = 'Completed' where ServiceName = @ServiceName
	end

	
	SET @error_code = 0              
	SET @error_message_xml ='Pass'              
	SET @filename = '' 

end try

begin catch
		IF @@TRANCOUNT > 0 ROLLBACK
		SET @ErrorSeverity = ERROR_SEVERITY()
		SET @ErrorState = ERROR_STATE()		
		SET	@ErrorLine = ERROR_LINE()
		SET @ErrorMsg = '[Line: '+ CAST(@ErrorLine AS VARCHAR(MAX)) + ']' + ERROR_MESSAGE()	

		SET	@signal_xml = NULL
		SET	@error_code = -1
		SET	@error_message_xml = @ErrorMsg
end catch

end

GO













