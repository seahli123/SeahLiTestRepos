if not exists (Select * from udtTMIArchiveSetting Where name = 'NumSourceRecords')
Insert into udtTMIArchiveSetting (name, value)	Values('NumSourceRecords',10)
 GO

  if not exists (Select * from udtTMIArchiveSetting Where name = 'NumRecordPerFile')
Insert into udtTMIArchiveSetting (name, value)	Values('NumRecordPerFile',2)
 GO

  if not exists (Select * from udtTMIArchiveSetting Where name = 'LastProcessId')
Insert into udtTMIArchiveSetting (name, value)	Values('LastProcessId',0)
 GO

